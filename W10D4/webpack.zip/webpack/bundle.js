/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************!*\
  !*** ./frontend/entry.js ***!
  \***************************/
console.log("hello world!");
/******/ })()
;
//# sourceMappingURL=bundle.js.map