class CartItem < ApplicationRecord

end
