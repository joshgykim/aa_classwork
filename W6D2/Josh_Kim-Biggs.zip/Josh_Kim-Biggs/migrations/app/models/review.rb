class Review < ApplicationRecord
  
end
